import Login from "./pages/loginPages/Login";
import "./components/style/index.scss"

function App() {
  return (
    <div className="App">
      <Login />
      
    </div>
  );
}

export default App;
